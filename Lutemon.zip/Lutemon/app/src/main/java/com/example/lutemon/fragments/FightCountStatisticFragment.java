package com.example.lutemon.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


import com.example.lutemon.R;
import com.example.lutemon.lutemons.Lutemon;
import com.example.lutemon.lutemons.Storage;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.List;

public class FightCountStatisticFragment extends Fragment {

    private Storage storage;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_fightstatistics, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        GraphView gvFights = view.findViewById(R.id.graph);

        BarGraphSeries<DataPoint> series = new BarGraphSeries<>();
        int i = 0;
        for (Lutemon lutemon : Storage.getInstance().getLutemons()) {
            series.appendData(new DataPoint(i, lutemon.getFightCount()), false, 100);
            i++;
        }

        gvFights.addSeries(series);
    }



}

