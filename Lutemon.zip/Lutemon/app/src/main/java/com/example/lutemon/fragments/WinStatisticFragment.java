package com.example.lutemon.fragments;

import androidx.fragment.app.Fragment;

public class WinStatisticFragment extends Fragment {
}
