package com.example.lutemon.locations;

import com.example.lutemon.lutemons.Storage;

public class BattleField {
    private Storage storage;

    public BattleField() {
        this.storage = Storage.getInstance();
    }

    public void fight() {

    }
}
