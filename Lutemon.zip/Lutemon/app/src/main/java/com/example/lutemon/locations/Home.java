package com.example.lutemon.locations;

import com.example.lutemon.lutemons.Lutemon;
import com.example.lutemon.lutemons.Storage;

public class Home {
    private Storage storage;

    public Home() {
        this.storage = Storage.getInstance();
    }


    public void createLutemon(Lutemon lutemon) {

    }

    public void healLutemon(Lutemon lutemon) {
        lutemon.setHealth(lutemon.getMaxHealth());
    }
}
