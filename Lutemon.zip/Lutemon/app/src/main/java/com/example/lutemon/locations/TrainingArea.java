package com.example.lutemon.locations;

import com.example.lutemon.lutemons.Storage;

public class TrainingArea {
    private Storage storage;

    public TrainingArea() {
        this.storage = Storage.getInstance();
    }
    public void train() {

    }
}
